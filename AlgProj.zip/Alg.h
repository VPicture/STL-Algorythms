//---------------------------------------------------------------------------
#ifndef AlgH
#define AlgH

#include <Classes.hpp>
#include <Controls.hpp>
#include <ExtCtrls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	   // IDE-managed Components
   TMemo *mData;
   TButton *bReset;
   TButton *bSort;
   TButton *bCount;
   TButton *bFind;
   TButton *bFill;
   TButton *bRandom;
   TButton *bReplace;
   TButton *bReverse;
   TButton *bCopy;
   TButton *bRCopy;
   TPanel *Panel2;
   TPanel *Panel4;
   TPanel *Panel3;
   TEdit *eFill;
   TEdit *eCountValue;
   TEdit *eCount;
   TEdit *eFind;
   TEdit *eFindIT;
   TEdit *eOldValue;
   TEdit *eReplace;
   TLabel *Label2;
   TLabel *Label3;
   TLabel *Label4;
   TLabel *Label5;
   TLabel *Label6;
   TLabel *Label11;
   TLabel *Label9;
   TLabel *Label10;
   TLabel *Label7;
   TLabel *Label1;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall bResetClick(TObject *Sender);
   void __fastcall bRandomClick(TObject *Sender);
   void __fastcall bSortClick(TObject *Sender);
   void __fastcall bFillClick(TObject *Sender);
   void __fastcall bRCopyClick(TObject *Sender);
   void __fastcall bCountClick(TObject *Sender);
   void __fastcall bFindClick(TObject *Sender);
   void __fastcall bReplaceClick(TObject *Sender);
   void __fastcall bCopyClick(TObject *Sender);
   void __fastcall bReverseClick(TObject *Sender);

private:	// User declarations
   void __fastcall UpdateMemo(void);
public:		// User declarations
   __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
