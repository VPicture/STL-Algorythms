//---------------------------------------------------------------------------
// We use a deque to demonstrate the algorithms because it has an iterator
#include <vcl.h>
#pragma hdrstop
                 
#include "Alg.h"
#include "Copy.h"
#include <set>
#include <list>
#include <stack>
#include <deque>
#include <iterator>
#include <algorithm>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#define Add mData->Lines->Add
//#define Line mData->Lines->Strings
TMainForm *MainForm;
using namespace std;
int Lines=9, IntData[] = {2,5,1,7,3,6,9,4,8};
int Copy[20];
int Size;
deque<int> MyInt(IntData, IntData + Lines);
deque<int>::iterator IT;
//set<int> MyInt;
//set<int>::iterator IT;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::UpdateMemo(void)
{  int i;

   Size = MyInt.size();
   IT = MyInt.begin();
   mData->Clear();
   for (i=0; i<Size; i++)
      Add(*IT++);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormShow(TObject *Sender)
{  int i, j;

   mData->Clear();
   MyInt.clear();
   IT = MyInt.begin();        // Point IT to begin og MyInt
   for (i=0; i < Lines; i++)  // Populate MyInt
   {  j = IntData[i];
      Add(j); // Add a new line to memo
      MyInt.push_back(j);
   }
//   bRCopy->Caption = "reverse\n_copy";   rnd
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bResetClick(TObject *Sender)
{  FormShow(this);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bRandomClick(TObject *Sender)
{  int i, d;

   Size = MyInt.size();
   random_shuffle(MyInt.begin(), MyInt.end());
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bSortClick(TObject *Sender)
{  Size = MyInt.size();
   sort(MyInt.begin(), MyInt.end());
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bFillClick(TObject *Sender)
{  int i, d;
   String s = eFill->Text;

   Size = MyInt.size();
   if (s == "")
      return;
   d = StrToInt(s);
   fill(MyInt.begin(), MyInt.end(), d);
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bRCopyClick(TObject *Sender)
{  int i;

   Size = MyInt.size();
   deque<int> D(Size);  // Destination deque
   reverse_copy(MyInt.begin(), MyInt.end(), D.begin());
//   eCopyB->Text = IntToStr(D.front());
//   eCopyE->Text = IntToStr(D.back());
   for (i=0; i<Size; i++)
      Copy[i] = D[i];
   Copy[i] = '?';
   CopyForm->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bCountClick(TObject *Sender)
{  int v, x;

   String s = eCountValue->Text;
   if (s == "")
      return;
   v = StrToInt(s);
   x = count(MyInt.begin(), MyInt.end(), v);
   eCount->Text = IntToStr(x);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bFindClick(TObject *Sender)
{  int f, index;
   bool found=0;

    Size = MyInt.size();String s = eFind->Text;
   if (s == "")
      return;
   f = StrToInt(s);
   IT = find(MyInt.begin(), MyInt.end(), f);
   index = distance(MyInt.begin(), IT);   // Convert iterator to index
   if (index == Size)
      ShowMessage("Can't find Value");
   else
      eFindIT->Text = IntToStr(index);
/* How to convert index to iterator
   IT = MyInt.begin() + index;
*/
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bReplaceClick(TObject *Sender)
{  int i, V, S;
   bool found=0;

   String v = eOldValue->Text;
   String s = eReplace->Text;
   if (s == "" || v == "")
      return;
   V = StrToInt(v);
   S = StrToInt(s);
   i = count(MyInt.begin(), MyInt.end(), V);
   if (i == 0)
   {  ShowMessage("Can't find Value to Replace.");
      return;
   }
   replace(MyInt.begin(), MyInt.end(), V, S);
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bCopyClick(TObject *Sender)
{  int i;

   deque<int> D(20);
   copy(MyInt.begin(), MyInt.end(), D.begin());
   Size = MyInt.size();
   for (int i=0; i<Size; i++)
      D.push_back(MyInt[i]);
//   eCopyB->Text = IntToStr(D.front());
//   eCopyE->Text = IntToStr(D.back());
   for (i=0; i<Size; i++)
      Copy[i] = D[i];
   Copy[i] = '?';
   CopyForm->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::bReverseClick(TObject *Sender)
{  Size = MyInt.size();
   reverse(MyInt.begin(), MyInt.end());
   UpdateMemo();
}
//---------------------------------------------------------------------------

