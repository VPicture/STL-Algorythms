//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Copy.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCopyForm *CopyForm;
#define Add mCopy->Lines->Add
extern int Copy[];
//---------------------------------------------------------------------------
__fastcall TCopyForm::TCopyForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TCopyForm::FormShow(TObject *Sender)
{  mCopy->Clear();
   for (int i=0; i<20;i++)
   {  if (Copy[i] == '?')
         break;
      Add(Copy[i]);
   }
   bOK->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TCopyForm::bOKClick(TObject *Sender)
{  ModalResult = 1;
}
//---------------------------------------------------------------------------
