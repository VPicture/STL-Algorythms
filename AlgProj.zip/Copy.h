//---------------------------------------------------------------------------
#ifndef CopyH
#define CopyH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TCopyForm : public TForm
{
__published:	// IDE-managed Components
   TMemo *mCopy;
   TButton *bOK;
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall bOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TCopyForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCopyForm *CopyForm;
//---------------------------------------------------------------------------
#endif
