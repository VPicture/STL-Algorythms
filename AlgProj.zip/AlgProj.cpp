//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("AlgProj.res");
USEFORM("Copy.cpp", CopyForm);
USEUNIT("AlgProj.cpp");
USEFORM("Alg.cpp", MainForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
       Application->Initialize();
       Application->CreateForm(__classid(TMainForm), &MainForm);
       Application->CreateForm(__classid(TCopyForm), &CopyForm);
       Application->Run();
   }
   catch (Exception &exception)
   {
       Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------
